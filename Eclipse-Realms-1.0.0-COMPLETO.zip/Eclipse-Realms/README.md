# Eclipse Realms — 1.0.0

Mod originale per **Minecraft Java Edition 1.21.1 + Fabric**.

## Contenuti

- 25 oggetti registrati, inclusi 7 blocchi, 4 pezzi di armatura e 6 oggetti con abilità attive.
- Asterite nel Sopramondo, lingotti, nucleo stellare e progressione attraverso materiali del Nether.
- Lama con fendente ad area; martello 3×3; ascia; bastone a raggio; amuleto del balzo; reliquia curativa.
- Custode dell’Eclisse con barra della vita, 3 fasi, guardie, nova e colonne astrali annunciate.
- Salute del boss scalata sul numero di combattenti vicini al rituale, fino a 4.
- Regno Astrale: isole sospese, cristalli luminosi, chorus, Endermen e notte fissa.
- 23 ricette, 8 avanzamenti visibili e un avanzamento nascosto per il ricettario.
- Codice astrale localizzato in italiano e inglese; impaginazione basata sul font del client.
- Texture pixel art originali, suoni vanilla, nessuna libreria esterna oltre a Fabric API.

## Installazione

1. Installa Fabric Loader **0.16.14 o superiore** per Minecraft **1.21.1**: https://fabricmc.net/use/installer/.
2. Usa Java 21. Inserisci `eclipse-realms-1.0.0.jar` e `fabric-api-0.116.6+1.21.1.jar` nella cartella `mods` della tua istanza.
3. Avvia il profilo Fabric. Ricevi il Codice astrale al primo ingresso.

Su server servono entrambi i file anche sui client. Non inserire due versioni di Fabric API nella stessa istanza. Il pacchetto pronto include la dipendenza corretta.

La generazione dell’Asterite avviene nei **chunk nuovi**, tra Y -56 e 24. Serve un piccone di ferro o migliore.

## Prova rapida

In un mondo di prova con comandi abilitati:

```text
/eclipse kit
```

Posiziona un altare e 4 blocchi di Asterite in questo schema, tutti alla stessa altezza:

```text
. . A . .
. . . . .
A . X . A
. . . . .
. . A . .
```

`X` è l’altare; `A` è un blocco di Asterite. Lascia 4 blocchi liberi sopra l’altare e un’arena ampia intorno. Usa il Sigillo sull’altare con difficoltà almeno Facile. Passa in Sopravvivenza per combattere.

- `/eclipse guide`: recupera il libro.
- `/eclipse kit`: kit da operatore (permesso 2).
- Tasto destro con gli oggetti per attivare i poteri. Il martello va nella mano principale e si usa cliccando la faccia del blocco.

Il Custode lascia 2 Cuori: uno per la Reliquia dell’Alba e uno per la Chiave della Fenditura. La Chiave torna allo **spawn del Sopramondo**, non al punto d’ingresso o al letto. Nel Regno Astrale letti e ancore non sono utilizzabili ed esplodono.

## Configurazione

Il primo avvio crea `config/eclipse-realms.json`. Modifica il file a gioco/server spento e riavvia.

| Campo | Default | Effetto |
| --- | --- | --- |
| `bossHealth` | 360 | Vita base; intervallo 80–4000 |
| `bossDamage` | 9 | Attacco base; intervallo 1–60 |
| `abilitiesHurtPlayers` | false | Consente danno PvP delle abilità, se consentito dal server |
| `abilityCooldownPercent` | 100 | Moltiplicatore tempi, da 25 a 400% |
| `giveGuideOnFirstJoin` | true | Codice al primo ingresso |
| `enableRealmTravel` | true | Ingresso nel Regno; l’uscita rimane sempre permessa |

Il danno delle normali armi segue il PvP vanilla. Le abilità offensive prendono di mira mostri ostili; gli attacchi speciali del boss non distruggono blocchi. Il martello rispetta lo scavo del server, salta contenitori e blocchi con entità e gestisce incantesimi e durabilità tramite il normale interaction manager. Compatibilità con mod di protezione di terze parti non verificata.

## Compilazione

Serve un **JDK 21** e Internet per il primo build. Imposta `JAVA_HOME` sul JDK, estrai questa cartella ed esegui:

```powershell
.\gradlew.bat build
```

macOS/Linux:

```sh
bash gradlew build
```

Il file installabile è `build/libs/eclipse-realms-1.0.0.jar`. Il file con suffisso `-sources.jar` è per lo sviluppo.

Le risorse sono già incluse. Per rigenerarle servono Python 3 e Pillow:

```sh
python generate_assets.py
```

## Test

```powershell
.\gradlew.bat -PeclipseTests runGameTest
```

I test funzionano nel server Minecraft senza interfaccia grafica. L’opzione include temporaneamente le classi in `src/gametest/java`. Il server GameTest vanilla crea tre dimensioni dal proprio preset; la generazione della dimensione aggiuntiva viene verificata separatamente.

Per la verifica con server dedicato locale, prepara `build/smoke/eula.txt` dopo aver letto e accettato la EULA di Minecraft e `build/smoke/server.properties` con `server-ip=127.0.0.1`, una porta libera, `level-seed=12345678`, `view-distance=2`. Poi:

```powershell
.\gradlew.bat -PeclipseTests runSmokeTest
```

Il server si arresta automaticamente e scrive `build/smoke/smoke-result.txt`. Un risultato `FAIL` va considerato errore anche se il processo termina normalmente.

Dopo i test, per una distribuzione senza classi di test:

```powershell
.\gradlew.bat clean build
```

Vedi `VERIFICA.md` per i risultati ottenuti durante la consegna. La compilazione e i test automatici non sostituiscono il collaudo grafico e il bilanciamento in partite reali.

## Progetto e licenze

Codice e texture originali: MIT, vedi `LICENSE`. Gradle Wrapper: Apache-2.0. Fabric API: Apache-2.0, con licenze incluse nel proprio archivio. Minecraft non è redistribuito. Il boss riusa la geometria e le animazioni dello scheletro vanilla, con scala e texture dedicate. I suoni sono quelli del gioco.

Documentazione di riferimento: [Fabric 1.21/1.21.1](https://fabricmc.net/2024/05/31/121.html), [Yarn 1.21.1 build 3](https://maven.fabricmc.net/docs/yarn-1.21.1+build.3/), [Fabric API](https://github.com/FabricMC/fabric).

Questo progetto non è un prodotto ufficiale Mojang o Microsoft.
