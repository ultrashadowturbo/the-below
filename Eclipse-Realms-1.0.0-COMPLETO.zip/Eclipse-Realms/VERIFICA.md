# Verifica della consegna

**Data:** 15 settembre 2026. **Target:** Minecraft Java 1.21.1, Fabric Loader 0.16.14, Fabric API 0.116.6+1.21.1, Java 21.

## Controlli eseguiti

- Compilazione Java del codice comune e del client; creazione del JAR rimappato per Fabric.
- **8/8 test GameTest obbligatori superati**, eseguiti nel server Minecraft:
  1. Caricamento di tutte le 23 ricette e dei registri del mondo.
  2. Livelli di scavo, riparazione degli attrezzi e registrazione dei 25 oggetti.
  3. Salute cooperativa del boss e persistenza della vita/equipaggiamento dopo salvataggio e caricamento NBT.
  4. Drop di almeno 2 Cuori dell’Eclisse alla morte del boss.
  5. Durabilità di armatura e bastone, tenacità e recupero base.
  6. Raggio bloccato da un muro; danno e Lentezza dopo la rimozione del muro.
  7. Cura esatta e blocco del secondo uso durante il recupero.
  8. Balzo su un punto libero senza attraversare un muro.
- **Server dedicato locale avviato e arrestato correttamente**: dimensione aggiuntiva presente, 4 chunk del Regno generati, **356 blocchi di cristallo** trovati con seed 12345678.
- Controllo statico delle risorse JSON, dei riferimenti a texture, delle localizzazioni, dell’archivio finale e dell’assenza delle classi di test nel JAR di distribuzione.
- Anteprima delle texture reali generata e ispezionata visivamente.

## Limiti della verifica

- Nessuna partita manuale con interfaccia grafica: animazioni, rendering dell’armatura, atmosfera, fluidità del combattimento e apertura della guida richiedono ancora un collaudo nel client.
- Nessuna sessione con più giocatori reali. La scalatura della salute e le azioni lato server sono verificate automaticamente; latenza e interazioni multiplayer non sono state misurate.
- Nessuna verifica con altri modpack o mod di protezione. La compatibilità dichiarata riguarda le versioni elencate sopra.
- Non sono incluse migrazioni di salvataggi da versioni precedenti della mod. Minecraft registra il messaggio `No data fixer registered` per l’entità personalizzata; l’avvio e il salvataggio/caricamento NBT sono stati verificati.

Il server GameTest vanilla crea le tre dimensioni del proprio preset: per questo la dimensione della mod è stata verificata anche su un server dedicato separato. Tutti i server di prova sono stati arrestati. Nessuna installazione è stata effettuata nelle istanze Minecraft personali.

## Riproducibilità

I sorgenti includono Gradle Wrapper 8.10.2 con SHA-256 della distribuzione, versioni delle dipendenze fissate, generatore delle risorse con semi deterministici e test in `src/gametest/java`. I comandi sono nel README.

Il pacchetto pronto contiene i JAR di Eclipse Realms e Fabric API. Minecraft, Fabric Loader, Java e i mondi usati per la verifica non sono redistribuiti.
